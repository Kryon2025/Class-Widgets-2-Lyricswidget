<div align="center">

<img src="icon.png" height="120" alt="歌词(Lyricsisland)">
<h1>歌词岛 (LyricsIsland) — Class Widgets 2</h1>

<p>在 <b>Class Widgets 2</b> 里显示当前播放歌曲的实时歌词组件。</p>

[![版本](https://img.shields.io/badge/%E7%89%88%E6%9C%AC-1.1.1-5A9BFF?style=for-the-badge)](https://github.com/Kryon2025/Class-Widgets-2-LyricsIsland/releases)
[![星标](https://img.shields.io/github/stars/Kryon2025/Class-Widgets-2-LyricsIsland?style=for-the-badge&color=orange&label=%E6%98%9F%E6%A0%87)](https://github.com/Kryon2025/Class-Widgets-2-LyricsIsland)
[![开源许可](https://img.shields.io/github/license/Kryon2025/Class-Widgets-2-LyricsIsland?style=for-the-badge&label=%E5%BC%80%E6%BA%90%E8%AE%B8%E5%8F%AF%E8%AF%81)](https://github.com/Kryon2025/Class-Widgets-2-LyricsIsland/blob/main/LICENSE)
[![下载量](https://img.shields.io/github/downloads/Kryon2025/Class-Widgets-2-LyricsIsland/total.svg?label=%E4%B8%8B%E8%BD%BD%E9%87%8F&color=green&style=for-the-badge)](https://github.com/Kryon2025/Class-Widgets-2-LyricsIsland/releases)

</div>

> [!NOTE]
> 当前版本 **1.1.1**，要求 Class Widgets 2 的插件 API `~=0.6.0`。
> 在 [插件广场](https://plaza.cw.rinlit.cn/plugins/com.lyricsisland) 可以一键安装/更新，也可以在 Release 页下载 `.cwplugin` 手动导入。

音乐软件侧向本地 `127.0.0.1:50063` 推送歌词，组件居中显示「上一句 / 当前句 / 附加行」三行；
同时从 **Windows 系统媒体会话（SMTC）** 读取真实播放进度、播放状态与专辑封面，
让逐字高亮、进度条、封面背景都跟着真实播放走。

本组件是 [LyricsIslandCW](https://github.com/jiangyin14/LyricsIslandCW)（Class Widgets 1 版歌词岛插件）的 **Class Widgets 2 移植版**。

## ✨ 特性

### 歌词显示
- **三行布局**：上一句 / 当前句 / 附加行，当前句放大突出
- **附加行智能区分**：与当前歌词同语种时判为「译文」（同字号、满亮度）；异语种时判为「下一句」（模糊虚化）
- **逐字高亮（卡拉OK）**：唱到的字逐个点亮并轻微上浮
- **超宽歌词横向滚动**：不循环，尽量在本句唱完之前滚到底

### SMTC 系统集成
- **播放进度条**：取自系统媒体会话的真实播放位置
- **专辑封面背景**：SMTC 封面 → 模糊 → 圆角遮罩，作为组件背景
- **配色自适应**：从封面算出主色与明暗，自动决定歌词用深色还是浅色
- **播放状态感知**：暂停时逐字高亮与横向滚动一起定格，恢复播放再接上

### 稳健性
- **SMTC 核验闸门**：只有当 SMTC 与歌词渠道确认是**同一首歌**时才启用 SMTC 功能；否则停用相关功能并释放封面等占用，只保留歌词自身能提供的效果
- **自动显隐**：暂停/停止约 10 秒后自动收起，恢复播放或收到新歌词立即弹出
- **优雅降级**：没有 SMTC、没有封面、没有时长时都能正常工作

## 📦 安装

1. 将整个 `com.lyricsisland` 文件夹放入 Class Widgets 2 的 `plugins/` 目录
2. 重启 Class Widgets 2
3. 在主界面添加「歌词」组件

组件自带 `libs/winrt`（Python/WinRT 运行时），**无需额外安装依赖**；即使 winrt 不可用，歌词显示部分仍然正常。

## 🔌 接入音乐软件

### 请求格式

```
POST http://127.0.0.1:50063/component/lyrics/lyrics/
Content-Type: application/json
```

支持的字段组合（都可选，取决于发送端能力）：

| 字段 | 说明 |
|---|---|
| `lyric` | 当前歌词文本 |
| `extra` | 附加歌词：译文，或下一句 |
| `lyrics` | 完整歌词表（数组），配合索引推送 |
| `progress` | 播放进度：`0.0–1.0` 的小数，或 `0–100` 的整数 |
| `position` + `duration` | 播放进度（秒），等价于 `progress` |

最小示例：

```json
{"lyric": "故事的小黄花", "extra": "从出生那年就飘着"}
```

### 网易云音乐（推荐）

1. 安装网易云音乐客户端
2. 安装 [BetterNCM](https://github.com/Redns/BetterNCM)
3. 在 BetterNCM 插件广场安装 **LyricsIsland** 插件
4. 重载插件，歌词即开始推送

### 其它软件

任何能向本地 HTTP 接口 POST 歌词的软件（如洛雪音乐）按上述格式推送即可。

> **端口占用**：请确保 `50063` 未被其它程序占用，否则组件无法监听。端口与数据格式与原版 LyricsIsland 保持一致，音乐软件端无需改动。
> 只推送歌词、不提供播放进度的软件，会走「按节奏估算」的降级路径。

## ⚙️ 设置项

| 设置 | 默认 | 说明 |
|---|---|---|
| 封面背景 | 开 | 读取 SMTC 专辑封面，模糊后作为组件背景 |
| 主歌词字号 | 13 px | 当前这一句的字号 |
| 上/下一句字号 | 10 px | 其余行的字号 |
| 歌词配色方案 | 自适应 | 见下表 |
| 自定义颜色 | `#ffffff` | 仅在配色方案选「自定义」时生效 |
| 显示播放进度条 | 开 | 组件底部进度条；拿不到进度时自动隐藏 |
| 未核验时也使用 SMTC 功能 | 关 | 打开后退回「没确认也用」的旧行为 |
| 逐字高亮 | 开 | 关闭后当前歌词整行保持满亮度 |
| 歌词弹出显示 | 开 | 控制自动弹出 / 自动收起 |

### 歌词配色方案

「自适应 / 鲜艳 / 柔和 / 偏色」都基于**封面的主色调**推导，并按封面明暗自动选择深色或浅色文字。

| 方案 | 效果 |
|---|---|
| **自适应** | 按封面明暗自动切换深色 / 浅色文字，遮罩底色同步翻转 |
| **深色** | 近黑文字 + 偏白遮罩 |
| **浅色** | 近白文字 + 偏黑遮罩 |
| **鲜艳** | 取封面色相、高饱和度，遮罩最淡，保留封面色彩冲击力 |
| **柔和** | 同色相但低饱和度、提亮/压暗，偏 pastel |
| **偏色** | 文字与遮罩都使用封面色相，整体色调统一 |
| **跟随主题** | 使用 Class Widgets 主题的文字色 |
| **自定义** | 手动指定颜色 |

## 🧠 工作原理

```
音乐软件 ──HTTP POST──▶ 127.0.0.1:50063 ──▶ 歌词行（当前句/附加行/索引）
                                              │
Windows SMTC ──▶ 播放位置 / 总时长 / 播放状态 / 专辑封面
                                              │
                                        ┌─────▼─────┐
                                        │  核验闸门  │  歌名相似度 + 歌手二次确认
                                        └─────┬─────┘
                              通过 ───────────┴─────────── 未通过
                    进度条 / 封面 / 逐字同步          停用上述功能并释放占用，
                                                       只保留歌词自身效果
```

- **歌词来源**：HTTP 渠道，是唯一的歌词来源
- **进度来源**：优先 SMTC 真实位置；歌词渠道自带 `progress`/`position` 时作为补充
- **核验**：把歌词渠道推送的歌名与 SMTC 当前歌名做相似度比对（并对歌手做二次确认），避免把 A 歌的进度显示到 B 歌的歌词上
- **逐字高亮**：核验通过时用 SMTC 真实位置驱动，每 500ms 校准一次；未通过时按上一句的实际时长估算节奏
- **封面平均色**：把封面缩到 `1×1` 取平均（等价于重度模糊后的观感），据此决定明暗与配色

> **协议限制**：上游 LyricsIsland 协议不含每句时间戳，因此「本句时长」是由相邻两次换行的 SMTC 位置差推算的，首句无法预估。逐字高亮属于**节奏估算**，不是逐字精确对齐。

## 🩺 排障

组件会在插件目录写一份 `smtc_debug.log`（超过 400 KB 自动清空重写），以及 `last_payload.json`（最近一次收到的推送）。日志里的事件：

| 事件 | 内容 |
|---|---|
| `song` | SMTC 检测到换歌 |
| `tick` | 每 10 秒一次的播放状态快照（位置、时长、是否播放、是否核验通过） |
| `match` | 核验结果变化（含歌词侧声明的歌名与候选歌词） |
| `gate` | SMTC 闸门开 / 关及原因 |
| `cover` | 封面处理结果（平均色、明暗） |
| `duration` | 网易云兜底补全的歌曲总时长 |

**常见现象对照：**

| 现象 | 原因 / 处理 |
|---|---|
| 完全没有歌词 | 检查 `50063` 是否被占用；检查音乐软件侧插件是否在推送（看 `last_payload.json`） |
| 进度条不显示 | 核验未通过（看 `gate` / `match`），或该播放器未提供总时长 |
| 没有封面背景 | 该歌曲的 SMTC 未提供缩略图（播放器/本地文件常见），可关闭「封面背景」 |
| 逐字高亮不同步 | 看 `tick` 事件里 `pos` 是否在变化；若不变，说明播放器未更新 SMTC 位置，此时会走估算路径 |
| 组件不自动收起 | `tick` 的 `playing` 字段是否变成了 `false`；不提供播放状态的播放器会走 60 秒无新歌词的兜底逻辑 |

## ⚠️ 已知限制

- 逐字高亮为**节奏估算**（上游协议无逐字时间戳），实际演唱可能提前或延后
- 首句无法预估时长，会退回按固定节奏估算
- SMTC 相关功能依赖 Windows 系统媒体会话：不支持 SMTC 的播放器不会提供进度、封面与播放状态
- 本地音乐文件可能没有内嵌封面，此时不会有封面背景

## 📁 目录结构

```
com.lyricsisland/
├── main.py               # 插件入口：HTTP 服务、歌词模型、核验闸门、封面处理
├── smtc_progress.py      # SMTC 播放进度 / 播放状态 / 专辑封面读取（独立线程）
├── netease_lyrics.py     # SMTC 缺时长时用网易云搜索兜底补全
├── qml/
│   ├── lyrics.qml        # 组件本体
│   └── lyrics-settings.qml  # 设置页
├── libs/winrt/           # 自带的 Python/WinRT 运行时（免安装依赖）
├── cwplugin.json         # 插件清单
├── README.md
└── LICENSE
```

运行时生成：`smtc_debug.log`、`last_payload.json`、`cover.png` / `cover.jpg`（未通过核验时会自动删除）。

## 📄 许可证与版权声明

本组件基于 **MIT 许可证** 开源。

**MIT License Copyright (c) 2024 jiangyin14 and 星标**

原插件作者（按贡献先后）：`jiangyin14`、`星标`、`沫烬染`、`Laoshui`、`Xwei1645`。

本移植版在保留上述版权声明的前提下，将插件升级适配至 Class Widgets 2。完整版权声明见 [LICENSE](./LICENSE)。

## 🙏 致谢

- 感谢 [LyricsIsland](https://github.com/jiangyin14/LyricsIsland) 原版作者 **jiangyin14** 与 **星标**
- 感谢 **沫烬染** 的「任务栏歌词」插件为本项目提供参考代码
- 感谢 **Laoshui** 与 **Xwei1645** 对原项目的贡献
- 感谢原版 [LyricsIslandCW](https://github.com/jiangyin14/LyricsIslandCW) 为 Class Widgets 1 提供歌词支持

## SDK 版本

本插件适配 Class Widgets 2 SDK **0.6.0**（`cwplugin.json` 中 `api_version: ~=0.6.0`），
使用官方 `ClassWidgets.SDK` 接口（`CW2Plugin` / `PluginAPI`）。
