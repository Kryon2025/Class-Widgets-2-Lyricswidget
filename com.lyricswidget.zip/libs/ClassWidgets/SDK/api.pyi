from typing import Any, Dict, List, Literal, Optional, Set, TypedDict, Union
from datetime import datetime
from pathlib import Path
from enum import Enum

from .notification import NotificationPayload, NotificationProvider
from .base_model import QObject, Signal


class ConfigBaseModel: ...

class ConfigManager: ...

class RuntimeMetaPayload(TypedDict):
    id: str
    version: int
    maxWeekCycle: int
    startDate: str


class RuntimeEntryPayload(TypedDict):
    id: str
    type: str
    startTime: str
    endTime: str
    subjectId: Optional[str]
    title: Optional[str]


class RuntimeEntryChangedPayload(TypedDict, total=False):
    id: str
    type: str
    startTime: str
    endTime: str
    subjectId: Optional[str]
    title: Optional[str]


class RuntimeSubjectPayload(TypedDict):
    id: str
    name: str
    simplifiedName: Optional[str]
    teacher: Optional[str]
    icon: Optional[str]
    color: Optional[str]
    location: Optional[str]
    isLocalClassroom: bool


class RuntimeRemainingTimePayload(TypedDict):
    minute: int
    second: int


class SettingsPagePayload(TypedDict):
    id: str
    page: str
    title: str
    icon: str


class ShortcutPayload(TypedDict):
    id: str
    name: str
    icon: str
    iconIsSource: bool
    owner: str


class ApplicationInfoPayload(TypedDict):
    name: str
    version: str
    channel: str
    pluginApiVersion: str
    platform: str


class DiagnosticLogPayload(TypedDict):
    time: str
    level: str
    message: str


class EntryType(str, Enum):
    CLASS = "class"
    BREAK = "break"
    FREE = "free"
    ACTIVITY = "activity"
    UNKNOWN = "unknown"


# WidgetsAPI
class WidgetsAPI:
    def __init__(self, app: Any) -> None: ...

    def register(
            self,
            widget_id: str,
            name: str,
            qml_path: Union[str, Path],
            backend_obj: Optional[QObject] = ...,
            settings_qml: Optional[Union[str, Path]] = ...,
            default_settings: Optional[Dict[str, Any]] = ...
    ) -> None: ...


# NotificationAPI
class NotificationAPI(QObject):
    pushed: Signal[NotificationPayload]

    def __init__(self, app: Any) -> None: ...

    def get_provider(
        self,
        provider_id: str,
        name: Optional[str] = ...,
        icon: Optional[Union[str, Path]] = ...,
        use_system_notify: bool = ...
    ) -> NotificationProvider: ...

    def register_provider(
        self,
        provider_id: str,
        name: Optional[str] = ...,
        icon: Optional[Union[str, Path]] = ...,
        use_system_notify: bool = ...
    ) -> NotificationProvider: ...


# ScheduleAPI
class ScheduleAPI:
    def __init__(self, app: Any) -> None: ...

    def get(self) -> Any: ...  # 返回 Schedule 对象

    def reload(self) -> None: ...

    def update(self, schedule_dict: Dict[str, Any]) -> bool: ...

    def set_readonly(self, readonly: bool) -> None: ...
    @property
    def readonly(self) -> bool: ...

# ScheduleManagementAPI
class ScheduleManagementAPI:
    def __init__(self, app: Any) -> None: ...

    def switch(self, name: str) -> bool: ...
    def list(self) -> List[Dict[str, str]]: ...
    def add(self, name: str) -> bool: ...
    def save(self, name: str) -> bool: ...


class ApplicationAPI:
    def __init__(self, app: Any) -> None: ...
    def get_info(self) -> ApplicationInfoPayload: ...
    def restart(self) -> None: ...


class DiagnosticsAPI:
    def __init__(self, app: Any) -> None: ...
    def get_logs(self, limit: int = ...) -> List[DiagnosticLogPayload]: ...

# ThemeAPI
class ThemeAPI(QObject):
    changed: Signal[str]

    def __init__(self, app: Any) -> None: ...

    def current(self) -> Optional[str]: ...


# RuntimeAPI
class RuntimeAPI(QObject):
    updated: Signal
    statusChanged: Signal[str]
    entryChanged: Signal[RuntimeEntryChangedPayload]

    def __init__(self, app: Any) -> None: ...

    # 时间属性
    @property
    def current_time(self) -> datetime: ...

    @property
    def current_day_of_week(self) -> int: ...

    @property
    def current_week(self) -> int: ...

    @property
    def current_week_of_cycle(self) -> int: ...

    @property
    def time_offset(self) -> int: ...

    # 日程属性
    @property
    def schedule_meta(self) -> Optional[RuntimeMetaPayload]: ...

    @property
    def current_day_entries(self) -> List[RuntimeEntryPayload]: ...

    @property
    def current_entry(self) -> Optional[RuntimeEntryPayload]: ...

    @property
    def next_entries(self) -> List[RuntimeEntryPayload]: ...

    @property
    def remaining_time(self) -> RuntimeRemainingTimePayload: ...

    @property
    def progress(self) -> float: ...

    @property
    def current_status(self) -> str: ...

    @property
    def current_subject(self) -> Optional[RuntimeSubjectPayload]: ...

    @property
    def current_title(self) -> Optional[str]: ...


# ConfigAPI
class ConfigAPI:
    def __init__(self, app: Any) -> None: ...

    def register_plugin_model(self, plugin_id: str, model: ConfigBaseModel) -> None: ...

    def get_plugin_model(self, plugin_id: str) -> Optional[ConfigBaseModel]: ...

    def save(self) -> Any: ...

# GlobalConfigAPI
class GlobalConfigAPI:

    def __init__(self, app: Any) -> None: ...

    @property
    def configs(self) -> ConfigManager: ...

    def lock(self, keys: str | List[str] | Set[str]) -> None: ...
    def unlock(self, keys: str | List[str] | Set[str]) -> None: ...
    def is_locked(self, key: str) -> bool: ...
    @property
    def locked_keys(self) -> Set[str]: ...


# AutomationAPI
class AutomationAPI:
    def __init__(self, app: Any) -> None: ...

    def register(self, task: Any) -> None: ...


# ActionsAPI
class ActionsAPI(QObject):
    def __init__(self, app: Any) -> None: ...

    def register(self, action_name: str, *parameter_types: type) -> Signal[Any]: ...

    def get(self, action_name: str) -> Signal[Any]: ...


# UiAPI
class UiAPI(QObject):
    settingsPageRegistered: Signal
    shortcutsChanged: Signal

    def __init__(self, app: Any) -> None: ...

    @property
    def pages(self) -> List[SettingsPagePayload]: ...

    @property
    def shortcuts(self) -> List[ShortcutPayload]: ...

    def register_shortcut(
            self,
            shortcut_id: str,
            name: str,
            icon: Union[str, Path],
            action: Any
    ) -> str: ...

    def set_shortcut_name(self, shortcut_id: str, name: str) -> bool: ...

    def unregister_plugin_shortcuts(self, plugin_id: str) -> None: ...

    def invoke_shortcut(self, shortcut_id: str) -> bool: ...

    def unregister_settings_page(self, qml_path: Union[str, Path]) -> None: ...

    def register_settings_page(
            self,
            qml_path: Union[str, Path],
            title: Optional[str] = ...,
            icon: Optional[str] = ...
    ) -> None: ...

# PluginAPI
class PluginAPI:
    def __init__(self, app: Any) -> None: ...

    def set_current_plugin(self, plugin: Any) -> None: ...

    @property
    def current_plugin(self) -> Any: ...

    widgets: WidgetsAPI
    notification: NotificationAPI
    schedule: ScheduleAPI
    theme: ThemeAPI
    runtime: RuntimeAPI
    config: ConfigAPI
    automation: AutomationAPI
    actions: ActionsAPI
    ui: UiAPI
    schedulemanagement: ScheduleManagementAPI
    globalconfig: GlobalConfigAPI
    application: ApplicationAPI
    diagnostics: DiagnosticsAPI


__all__ = [
    'RuntimeMetaPayload',
    'RuntimeEntryPayload',
    'RuntimeEntryChangedPayload',
    'RuntimeSubjectPayload',
    'RuntimeRemainingTimePayload',
    'SettingsPagePayload',
    'ShortcutPayload',
    'ApplicationInfoPayload',
    'DiagnosticLogPayload',
    'EntryType',
    'WidgetsAPI',
    'NotificationAPI',
    'ScheduleAPI',
    'ThemeAPI',
    'RuntimeAPI',
    'ConfigAPI',
    'AutomationAPI',
    'ActionsAPI',
    'UiAPI',
    'PluginAPI',
    'ScheduleManagementAPI',
    'GlobalConfigAPI',
    'ApplicationAPI',
    'DiagnosticsAPI',
]
